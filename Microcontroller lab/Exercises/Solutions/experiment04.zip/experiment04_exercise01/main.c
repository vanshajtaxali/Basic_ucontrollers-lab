#include <templateEMP.h>


// +++++++++++++++
// ++ CONSTANTS ++
// +++++++++++++++

// Pin names
enum {
	RANGE1 = 204,
	RANGE2 = 408,
	RANGE3 = 612,
	RANGE4 = 816
};



// +++++++++++++++++++++++++
// ++ FUNCTION DEFINITION ++
// +++++++++++++++++++++++++

// Initializes the register direction
void initIO();

// Initializes the shift register with one LED on
void initShiftReg(char pos);

// CLKs once.
void clkSignal();



// +++++++++++++++++++
// ++ MAIN FUNCTION ++
// +++++++++++++++++++

int main(void) {
	int led[3] = {BIT0 , BIT1, BIT2};
	initMSP();
	initIO();
	
	// ADC10 is on.
	ADC10CTL0  =  (ADC10ON);

	// 16 x ADC10CLKs.
	ADC10CTL0 &= ~(ADC10SHT_1);
	ADC10CTL0 |=  (ADC10SHT_2);

	// Analog input for potentiometer enabled.
	ADC10AE0 = (BIT4 | BIT5);

	while (1) {
		//												EXERCISE A

		// Conversation disabled.
		ADC10CTL0 &= ~ENC;

		// Input channel select set to A5.
		ADC10CTL1 = INCH_5;

		// Conversation enabled. Start sample and conversion.
		ADC10CTL0 |= ENC + ADC10SC;

		// Waits when ADC10 is busy.
		while (ADC10CTL1 & ADC10BUSY);

		// Gets the current adc_output of the ADC.
		int adc_output = ADC10MEM;

		// Sets the LEDs depending on the adc_output.
		if (adc_output < RANGE1) {
			initShiftReg(0);
		} else if (adc_output < RANGE2) {
			initShiftReg(1);
		} else if (adc_output < RANGE3) {
			initShiftReg(2);
		} else if (adc_output < RANGE4) {
			initShiftReg(3);
		} else {
			initShiftReg(4);
		}

		//												EXERCISE B

		// Green chip: 0: 370   1: 353   2: 413
		// Blue  chip: 0: 400   1: 336   2: 371
		// Red   chip: 0: 392   1: 410   2: 380
		// White chip: 0: 656   1: 646   2: 655
		// Black chip: 0: 160   1: 108   2: 171
		// No    chip: 0: 575   1: 575   2: 575

		// Conversation disabled.
		ADC10CTL0 &= ~ENC;

		// Input channel select set to A5.
		ADC10CTL1 = INCH_4;

		int i = 0;
		int col[3];
		for (i = 0; i < 3; i++) {
			// Conversation enabled. Start sample and conversion.
			ADC10CTL0 |= ENC + ADC10SC;

			P3OUT |= led[i];
			__delay_cycles(100000);

			// Waits when ADC10 is busy.
			while (ADC10CTL1 & ADC10BUSY);

			col[i] = ADC10MEM;
		}

		// No chip, solved via exclusion deduced from given values.
		if ((col[0] <= 600) && col[0] >= 550) {
			serialPrintln("No chip detected");
		}
		// Black chip
		else if (col[0] <= 185) {
			serialPrintln("Black chip");
		}
		// White chip
		else if (col[0] >= 621) {
			serialPrintln("Green chip");
		}
		// Red chip
		else if (col[1] >= 385) {
			serialPrintln("Red chip");
		}
		// Blue chip
		else if ((col[2] <= 374) && (col[0] >= 385) && (col[1] <= 344)) {
			serialPrintln("Blue chip");
		}
		// Green chip
		else if ((col[0] < 385) && (col[1] >= 345) && (col[2] > 374)) {
			serialPrintln("Green chip");
		}
	}
}



// ++++++++++++++++++++++++++
// ++ FUNCTION-DECLARATION ++
// ++++++++++++++++++++++++++

void clkSignal() {
  P2OUT |=  BIT4;
  P2OUT &= ~BIT4;
}

// -----------------------------------------------------------------------------------------
void initIO() {
  // Set pins as I/O pins
  P2SEL &= ~(BIT0 + BIT1 + BIT2 + BIT3 + BIT4 + BIT5 + BIT6 + BIT7);
  P2SEL2 &= ~(BIT0 + BIT1 + BIT2 + BIT3 + BIT4 + BIT5 + BIT6 + BIT7);

  // Outputs
  P2DIR |=  (BIT0 | BIT1 | BIT2 | BIT3 | BIT4 | BIT5 | BIT6);
  // Inputs
  P2DIR &= ~(BIT7);

  // Set all outputs to low
  P2OUT &= ~(BIT0 + BIT1 + BIT2 + BIT3 + BIT4 + BIT5 + BIT6 + BIT7);

  // Set 3.0, 3.1, 3.2 as output
  P3DIR |= (BIT0 | BIT1 | BIT2);

  // Set 1.4 as input
  P1DIR &= ~(BIT4);
}

// -----------------------------------------------------------------------------------------
void initShiftReg(char pos) {
  char cnt = 0;
  // Turn off all LEDs --> 0000
  P2OUT &= ~BIT5;
  P2OUT |=  BIT5;

  // Set both shift registers to 'right shift'-mode
  P2OUT |= BIT0;
  P2OUT |= BIT2;

  // Select next input to be HIGH
  P2OUT |= BIT6;

  // CLK-signal: pos=1 --> 1000, pos=2 --> 0100 ...
  while (cnt < pos) {
    clkSignal();
    cnt++;
  }
}
