/*
 * INFO
 */

// Include the given template
#include <templateEMP.h>

void pb5Pressed(int *cnt);
void pb5PressedInterrupt(int *cnt);

// Main function
void main(void) {
	// Initialize controller
	initMSP();

	// Needed when not using the interrupt.
	// int cnt = 0;

	P1DIR  &= ~(BIT3 | BIT4); 				// INPUT, PB5 and PB6
	P1DIR  |=  (BIT5 | BIT6 | BIT0 | BIT7); // OUTPUT, LED rt and LED gn

	P1REN  |=  (BIT3 | BIT4); 				// Enable pull-up/-down resistor
	P1OUT  |=  (BIT3 | BIT4); 				// Set to pull-up

	P1SEL  &= ~(BIT3 | BIT4); 				// Select IO function
	P1SEL2 &= ~(BIT3 | BIT4); 				// Select IO function

	P1IE   |=  (BIT3);						// Interrupt enabled
	P1IES  |=  (BIT3);						// Interrupt edge is set to high-to-low transition
	P1IFG  &= ~(BIT3);						// Clears interrupt flag


	while (1) {
		// PB5 and red/yellow LED cycle, not debounced
		//pb5Pressed(&cnt);


		// PB6 and green LED cycle
		// Button pressed
		if ((P1IN & BIT4) == 0) {
			P1OUT |= BIT6;
		}
		// Button not pressed
		else if ((P1IN & BIT4) != 0) {
			P1OUT &= ~BIT6;
		}

		// PB5 and PB6 and blue LED cycle
		// Both pressed
		if ((P1IN & (BIT3 | BIT4)) == 0) {
			P1OUT |= BIT0;
		}
		else {
			P1OUT &= ~(BIT0);
		}
	}
}

#pragma vector = PORT1_VECTOR
__interrupt void Port_1() {
	int cnt = 0;
	pb5PressedInterrupt(&cnt);
	P1IFG &= ~(BIT3);
}

void pb5PressedInterrupt(int *cnt) {
	// Button pressed for a short time, here 50 ms
	while((*cnt) < 50) {
		P1OUT |= BIT5;
		P1OUT &= ~BIT7;
		__delay_cycles(1000); // delay 10 ms
		(*cnt)++;
	}

	// Reset
	P1OUT &= ~BIT5;
	P1OUT |= BIT7;
	*cnt = 0;
}


/*void pb5Pressed(int *cnt) {
	// Button not pressed
	if ((P1IN & BIT3) != 0) {
		P1OUT &= ~BIT5;
		P1OUT |= BIT7;
		*cnt = 0;
	}
	// Button pressed for a short time, here 50 ms
	else if (((P1IN & BIT3) == 0) && (*cnt < 50)) {
		P1OUT |= BIT5;
		P1OUT &= ~BIT7;
		__delay_cycles(1000); // delay 10 ms
		(*cnt)++;
	}
	// Button pressed for a long time
	else {
		P1OUT &= ~BIT5;
		P1OUT |= BIT7;
	}
}
*/
