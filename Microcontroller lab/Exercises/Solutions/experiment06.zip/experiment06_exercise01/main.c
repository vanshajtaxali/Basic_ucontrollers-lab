#include <templateEMP.h>

// Connection instructions:
// P1.0 - X5  |  P1.3 - X7  |  P3.6 - CON4.1(left)
// CON4.3(right)  - DAC_IN  |  CON4.2(middle) - X1

#define COMP_OUT BIT3
#define REL_STAT BIT0
#define BUZZER BIT6

// _____________________________________________________________________________________
// ++++++++++++++++++++++
// ++ GLOBAL VARIABLES ++
// ++++++++++++++++++++++

static int interruptSet;
long time;
int buttonPressedTwice;

// _____________________________________________________________________________________
// ++++++++++++++
// ++ MELODIES ++
// ++++++++++++++

int melody[2][5] = {
		{100, 600, 300, 400, 500},
		{900, 0, 1000, 100, 400},
};


// _____________________________________________________________________________________
// ++++++++++++++++++++++++++
// ++ FUNCTION DEKLARATION ++
// ++++++++++++++++++++++++++

// Sets the direction
void initDir();
// Initializes the Interrupt on COMP_OUT (P1.0)
void initInterrupt();
// Initializes the PWM on P3.6
void initPWM();
// Plays a tone.
void play(int tone);
// Stops the tone.
void stop();
// Plays Melody 1
void playMelodyOne();
// Plays Melody 2
void playMelodyTwo();


// _____________________________________________________________________________________
// +++++++++++++++++++
// ++ MAIN FUNCTION ++
// +++++++++++++++++++

int main () {
	initMSP();

	initDir();
	initInterrupt();
	initPWM();

	while (1) {
		// Set relay in 'detecting a tone'-mode.
		P1OUT &= ~REL_STAT;
		// Check that interrupts aren't set yet.
		interruptSet = 0;
		// Enable interrupts.
		P1IFG &= ~COMP_OUT;

		while (interruptSet < 1);

		// Disable interrupts.
		P1IFG |= COMP_OUT;

		// Used for debouncing purposes.
		_delay_cycles(50000);


		time = 0;
		buttonPressedTwice = 0;
		while (time < 30000) {
			time++;
			if ((P1IN & COMP_OUT)) {
				buttonPressedTwice = 1;
			}
		}

		// Set relay in 'play a tone'-mode.
		P1OUT |= REL_STAT;

		if (buttonPressedTwice > 0) {
			playMelodyTwo();
		}
		else {
			playMelodyOne();
		}
	}
}


// _____________________________________________________________________________________
// ++++++++++++++++++++++++++
// ++ FUNCTION DEFINITIONS ++
// ++++++++++++++++++++++++++

// _____________________________________________________________________________________
void initDir() {
	// INPUT:
	P1DIR &= ~COMP_OUT;

	// OUTPUT:
	P1DIR |= REL_STAT;
	P3DIR |= BUZZER;

	// Choose I/O f�r COMP_OUT and REL_STAT.
	P1SEL &= ~(REL_STAT + COMP_OUT);
	P1SEL2 &= ~(REL_STAT + COMP_OUT);
}


// _____________________________________________________________________________________
void initInterrupt() {
	// Enable interrupt on P1.3.
	P1IE |= COMP_OUT;
	// Interrupt edge set to H-L (Button released).
	P1IES |= COMP_OUT;
	// Interuppt flag: interrupt is pending
	P1IFG &= ~COMP_OUT;
}


// _____________________________________________________________________________________
void initPWM(){
	// TA0.2 option
	P3SEL |= BUZZER;
	P3SEL2 &= ~BUZZER;
	// CCR2 set / reset
	TA0CCTL2 = OUTMOD_3;
	// PWM Period : 1000 us
	TA0CCR0 = 1000;
	// SMCLK ; MC_1 -> up mode ;
	TA0CTL = TASSEL_2 + MC_1;
}


// _____________________________________________________________________________________
void play(int tone) {
	TA0CCR2 = tone;
	__delay_cycles(200000);
}


// _____________________________________________________________________________________
void stop() {
	TA0CCR2 = 1000;
}


// _____________________________________________________________________________________
void playMelodyOne() {
	int i;
	for (i = 4; i >= 0; i--) {
		play(melody[0][4 - i]);
		stop();
	}
}


// _____________________________________________________________________________________
void playMelodyTwo() {
	int i;
	for (i = 4; i >= 0; i--) {
		play(melody[1][4 - i]);
		stop();
	}
}


// _____________________________________________________________________________________
// +++++++++++++++
// ++ INTERRUPT ++
// +++++++++++++++

// Port 1 interrupt vector
# pragma vector = PORT1_VECTOR;
__interrupt void Port_1(void) {
	interruptSet++;
	P1IFG &= ~COMP_OUT;
}
