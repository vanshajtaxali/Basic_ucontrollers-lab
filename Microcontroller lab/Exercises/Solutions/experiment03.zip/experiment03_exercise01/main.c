// Author: Nico Buehler <buehleni@gmail.com>

/*
 * Experiment 3 - Mikrocomputertechnik Praktikum, University of Freiburg
 *
 * Description:
 * Simulation of a cassette recorder.
 *
 * Implementation:
 * First shift register (SREG1) gets parallel input via push-buttons PB1 ... PB4.
 * Second shift register (SREG2) is controlled through these inputs.
 * Realized by polling.
 */

#include <templateEMP.h>


// +++++++++++++++
// ++ CONSTANTS ++
// +++++++++++++++

// Pin names
enum {
	PB1 = 3,
	PB2 = 2,
	PB3 = 1,
	PB4 = 0,
	CNT_1HZ = 100,
	CNT_REWIND = 40,
	CNT_2HZ = 50,
	CNT_VALUE = 700
};


// +++++++++++++++++++++++++
// ++ FUNCTION-DEFINITION ++
// +++++++++++++++++++++++++

// Initializes the register direction
void initIO();

// Initializes the shift register with one LED on
void initShiftReg(char pos);

// Checks if a button is pressed and returns the buttons position:
// 0->D (PB4) | 1->C (PB3) | 2->B (PB2) | 3->A (PB1) | 4->no_input
char button();

// CLK: Sets P2.4 HIGH and then LOW again
void clkSignal();

int freq(char freq);

// Sets the direction for the LED:
// 'l'->LEFT | 'r'->RIGHT | OTHERS->STOP
void setDir(char dir);

// Sets direction and returns the frequency
char play();

// Sets direction and returns the frequency
char stop();

// Sets direction and returns the frequency
char forward();

// Sets direction and returns the frequency
char rewind();

// +++++++++++++++++++
// ++ MAIN-FUNCTION ++
// +++++++++++++++++++

void main(void) {
  initMSP();

  initIO();
  initShiftReg(1);

  char current_button = 4;

  setDir('s');

  int cnt = 0;
  char pos = 1;
  char current_state = 's';
  char freq = 1;


  while (1) {
	// Gets the user input
	current_button = button();

	// Button control
	switch (current_button) {
	  case PB1:
		freq = rewind();
		break;
	  case PB2:
		current_state = 's';
		freq = stop();
		break;
	  case PB3:
		current_state = 'p';
		freq = play();
		break;
	  case PB4:
		freq = forward();
		break;
	  default:
	    switch (current_state) {
		  case 's': freq = stop(); break;
		  case 'p': freq = play(); break;
	    }
	    break;
	}

	// CLK's, when counter reaches a defined value. Sets pos to the correct value.
	if (cnt >= CNT_VALUE) {
	  clkSignal();
	  if (((P2OUT & BIT0) == BIT0) && ((P2OUT & BIT1) != BIT1)) {
	  	pos++;
	  }
	  else if (((P2OUT & BIT0) != BIT0) && ((P2OUT & BIT1) == BIT1)) {
	    pos--;
      }
	  cnt = 0;
	}
	cnt++;

	// Sets the frequency depending on freq
	switch (freq) {
	  case 1: __delay_cycles(CNT_1HZ); break;
	  case 2: __delay_cycles(CNT_2HZ); break;
	  case 3: __delay_cycles(CNT_REWIND); break;
	}

	// If LED gets shifted out, returns it to the correct position
	switch (pos) {
	  case 0: stop(); initShiftReg(4); pos = 4; freq = rewind(); break;
	  case 5: initShiftReg(1); pos = 1; break;
	}
  }
}


// ++++++++++++++++++++++++++
// ++ FUNCTION-DECLARATION ++
// ++++++++++++++++++++++++++

void initIO() {
  // Set pins as I/O pins
  P2SEL &= ~(BIT0 + BIT1 + BIT2 + BIT3 + BIT4 + BIT5 + BIT6 + BIT7);
  P2SEL2 &= ~(BIT0 + BIT1 + BIT2 + BIT3 + BIT4 + BIT5 + BIT6 + BIT7);

  // Outputs
  P2DIR |=  (BIT0 | BIT1 | BIT2 | BIT3 | BIT4 | BIT5 | BIT6);
  // Inputs
  P2DIR &= ~(BIT7);

  // Set all outputs to low
  P2OUT &= ~(BIT0 + BIT1 + BIT2 + BIT3 + BIT4 + BIT5 + BIT6 + BIT7);
}

// -----------------------------------------------------------------------------------------
void initShiftReg(char pos) {
  char cnt = 0;
  // Turn off all LEDs --> 0000
  P2OUT &= ~BIT5;
  P2OUT |=  BIT5;

  // Set both shift registers to 'right shift'-mode
  P2OUT |= BIT0;
  P2OUT |= BIT2;

  // Select next input to be HIGH
  P2OUT |= BIT6;

  // CLK-signal
  clkSignal();

  // Selects next input to be LOW
  P2OUT &= ~BIT6;

  // CLK-signal: pos=1 --> 1000, pos=2 --> 0100 ...
  while (cnt < pos - 1) {
    clkSignal();
    cnt++;
  }
}

// -----------------------------------------------------------------------------------------
char button() {
  char posOfButtonPressed = 0;
  // Disable CLK-sensitivity for SREG2, while CLK-ing SREG1
  int current_mode = ((P2OUT & BIT0) | (P2OUT & BIT1));
  P2OUT &= ~(BIT0 | BIT1);

  // Enable parallel input for SREG1
  P2OUT |= (BIT2 | BIT3);

  // CLK for getting parallel input
  clkSignal();

  // Enable right-shift mode
  P2OUT |=  BIT2;
  P2OUT &= ~BIT3;

  // Looks for a button pressed
  while (!(P2IN & BIT7) && posOfButtonPressed < 4) {
	// Clocks for next input
    clkSignal();
	posOfButtonPressed++;
  }

  // Re-enable CLK for SREG1. Reset SREG1 in correct mode
  P2OUT |= current_mode;

  return posOfButtonPressed;
}

// -----------------------------------------------------------------------------------------
void clkSignal() {
  P2OUT |=  BIT4;
  P2OUT &= ~BIT4;
}

// -----------------------------------------------------------------------------------------
int freq(char freq) {
  switch (freq) {
    case 1:
      return CNT_1HZ;
    case 2:
      return CNT_2HZ;
    default:
      return 0;
  }
}

// -----------------------------------------------------------------------------------------
void setDir(char dir) {
  switch (dir) {
    // Move right
    case 'r':
      P2OUT |=  BIT0;
      P2OUT &= ~BIT1;
      break;
    // Move left
    case 'l':
      P2OUT &= ~BIT0;
      P2OUT |=  BIT1;
      break;
      // Else stop
    default:
      P2OUT &= ~BIT0;
      P2OUT &= ~BIT1;
      break;
  }
}

// -----------------------------------------------------------------------------------------
char play() {
	setDir('r');
	return 1;
}

// -----------------------------------------------------------------------------------------
char stop() {
	setDir('s');
	return 1;
}

// -----------------------------------------------------------------------------------------
char forward() {
	setDir('r');
	return 2;
}

// -----------------------------------------------------------------------------------------
char rewind() {
	setDir('l');
	return 3;
}
