/*
 * This programm will toggle pin 1.4 (connected to K3, red LED) every 1000 ms and
 * pin 1.5 (connected to K4, blue LED) every 500 ms (approx.)
 */

// Include the given template
#include <templateEMP.h>

// Main function - this one is called when the chip is connected to the power
void main(void) {

  // Initialize controller - *ALWAYS* call this *FIRST*. It's in the template,
  // so you have to include that as well. See the lecture notes for details.
  initMSP();

  // Set P1.4 and P1.5 as output
  P1DIR |= (BIT4 | BIT5);

  // Declares possible states.
  // S0: both LEDs toggle.
  // S1: only red LED toggles.
  char state = 0;
  char cnt = 0;

  // Main part of the programm: We do the following stuff until the
  // power is cut.
  while (1)
  {
	  if (cnt <= 0) {
		  switch (state) {
		  case 0:
			  P1OUT ^= (BIT4 | BIT5);
			  state = 1;
			  break;
		  case 1:
			  P1OUT ^= BIT4;
			  state = 0;
			  break;
		  default:
			  break;
		  }
		  cnt = 50;
	  }
	  __delay_cycles(10000); // 10 ms
	  cnt--;
	  if (serialAvailable()) {
	    serialRead();
	    switch (P1OUT & BIT5) {
	    case BIT5:
	    	serialPrint("OFF ");
	    	break;
	    default:
	    	serialPrint("ON ");
	    	break;
	    }
	   }
  }
}

/*
 * Die Bruecke ueber fuer den Heater muss herausgenommen werden. Stattdessen ist dorthin das Kabel zu fuehren.
 * Mit diesem Pin kann auch der Heater angesteuert werden. Dieser ist parallel zur Diode geschalten und kann
 * bei gegebener SEL-Register Belegung stattdessen genutzt werden.
 */
