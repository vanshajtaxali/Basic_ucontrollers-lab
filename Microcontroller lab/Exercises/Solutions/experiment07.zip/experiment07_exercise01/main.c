// Copyright: Nico Buehler, 2016
// Author: Nico Buehler, 3917577, 2016


#include <templateEMP.h>

// Exercise 1
#define GR_LED BIT0
#define PB5 BIT3
// Exercise 2
#define REL_STAT BIT4
#define REL_DYN BIT5
#define U_NTC BIT5
#define RD_LED BIT2
#define RANGE1 358
#define RANGE2 389
#define RANGE3 416
#define RANGE4 440



// _____________________________________________________________________________________
// ++++++++++++++++++++++
// ++ GLOBAL VARIABLES ++
// ++++++++++++++++++++++

static int button_pressed;
static int heat;
static int cnt;



// _____________________________________________________________________________________
// ++++++++++++++++++++++++++
// ++ FUNCTION DEKLARATION ++
// ++++++++++++++++++++++++++

// Exercise 1. Get in touch with the Watchdog Timer.
void exercise1();
// Set the direction for used pins.
void initDir();
// Initializes the interrupt on PB5 (P1.0)
void initInterrupt();

// Exercie 2.
void exercise2();
// Initializes the ADC
void initADC();
// Sets Diode 1 to 4.
void setSREG(char pos);
// Clock signal for SREG.
void clkSignal();


// _____________________________________________________________________________________
// +++++++++++++++++++
// ++ MAIN FUNCTION ++
// +++++++++++++++++++
int main(void) {
  // Uncomment this to use exercise 1.
  // exercise1();

  exercise2();
}



// _____________________________________________________________________________________
// ++++++++++++++++++++++++++
// ++ FUNCTION DEFINITIONS ++
// ++++++++++++++++++++++++++


void exercise1() {
  WDTCTL = (WDTPW | WDTHOLD);

  initMSP();
  initDir();  // Set the direction
  initInterrupt();  // Initialize the interrupt.

  button_pressed = 0;  // Variable for checking wheather interrupt was caused (PB5 pressed).

  // Watchdog - Password, clk source: ACLK, count clear.
  WDTCTL = (WDTPW | WDTSSEL | WDTCNTCL);

  // Set the divider for the ACLK to 1/2.
  BCSCTL1 &= ~(DIVA1);
  BCSCTL1 |=  (DIVA0);
  // LF clk set to VLOCLK.
  BCSCTL3 |=  (LFXT1S1);
  BCSCTL3 &= ~(LFXT1S0);

  // While button is not pressed, toggle LED
  while (!button_pressed) {
    P1OUT ^= GR_LED;  // Toggle green LED.
    __delay_cycles(125000);  // delay 125 ms.
  }
  P1OUT &= ~GR_LED;  // Switch off green LED.
  // Do nothing.
  while (1) {}
}


// _____________________________________________________________________________________
void initInterrupt() {
	// Enable interrupt on P1.0.
	P1IE  |= PB5;
	// Interrupt edge set to H-L (Button released).
	P1IES |= PB5;
	// Interuppt flag: interrupt is pending.
	P1IFG &= ~PB5;
}


// _____________________________________________________________________________________
void exercise2() {
  cnt = 0;

  WDTCTL = (WDTPW | WDTHOLD);

  // Set the divider for the ACLK to 1/8.
  BCSCTL1 |= (DIVA0 | DIVA1);
  // LF clk set to VLOCLK.
  BCSCTL3 |=  (LFXT1S1);
  BCSCTL3 &= ~(LFXT1S0);

  initMSP();
  initDir();
  initInterrupt();
  initADC();

  button_pressed = 0;  // Variable for checking whether interrupt was caused (PB5 pressed).

  TACCTL0 = CCIE;  // Enable timer interrupt.
  TACCR0 = 60;  // cnt to 750.
  TACTL = (TASSEL0 | MC0 | ID0 | ID1);  // ACLK, divider 8, upmode.

  // Set the ACLK divider to 1/8.
  BCSCTL1 |=  (DIVA0 | DIVA1);

  // LF clk set to VLOCLK.
  BCSCTL3 |=  (LFXT1S1);
  BCSCTL3 &= ~(LFXT1S0);

  // WDT - Password, clk source: ACLK, count clear.
  WDTCTL = (WDTPW | WDTSSEL | WDTCNTCL);

  while (!button_pressed) {
	// LED output for displaying the current heat and heat control.
	if (heat < RANGE1) {
	  P3OUT &= ~RD_LED;
	  setSREG(1);
	} else if (heat < RANGE2) {
	  P3OUT &= ~RD_LED;
	  setSREG(2);
	} else if (heat < RANGE3) {
	  P3OUT &= ~RD_LED;
	  setSREG(3);
	} else if (heat < RANGE4) {
	  P3OUT &= ~REL_DYN;
	  P3OUT &= ~RD_LED;
	  setSREG(4);
	} else {
	  P3OUT &= ~REL_DYN;
	  setSREG(0);
	  P3OUT |=  RD_LED;
	}
  }

  // Reset WDT.
  WDTCTL = (WDTPW + WDTSSEL + WDTCNTCL);

  // Do nothing.
  while (1) {}
}


// _____________________________________________________________________________________
void initDir() {
  // INPUT:
  P1DIR &= ~(U_NTC | PB5);

  // OUTPUT:
  P1DIR |= (GR_LED);
  P2DIR |= (BIT0 | BIT1 | BIT4 | BIT5 | BIT6);
  P3DIR |= (RD_LED | REL_STAT | REL_DYN);

  // IO FUNCTION:
  P1SEL  &= ~(GR_LED | PB5 | U_NTC);
  P1SEL2 &= ~(GR_LED | PB5 | U_NTC);

  P2SEL  &= ~(BIT0 | BIT1 | BIT4 | BIT5 | BIT6);
  P2SEL2 &= ~(BIT0 | BIT1 | BIT4 | BIT5 | BIT6);

  P3SEL  &= ~(RD_LED | REL_STAT | REL_DYN);
  P3SEL2 &= ~(RD_LED | REL_STAT | REL_DYN);

  // ENABLE PULL-UP RESISTORS:
  P1REN |= PB5;
  P1OUT |= PB5;

  // SET SREG OUTPUTS LOW:
  P2OUT  &= ~(BIT0 + BIT1 + BIT4 + BIT5 + BIT6);

  // INIT SIGNAL
  P1OUT &= ~(GR_LED);
  P2OUT &= ~(BIT0 | BIT1 | BIT4 | BIT5 | BIT6);
  P2OUT |=  (BIT5);
  P3OUT &= ~(RD_LED | REL_STAT | REL_DYN);
}

// _____________________________________________________________________________________
void initADC() {
  // ADC10 is on.
  ADC10CTL0  =  (ADC10ON);

  // 16 x ADC10CLKs.
  ADC10CTL0 &= ~(ADC10SHT_1);
  ADC10CTL0 |=  (ADC10SHT_2);

  // Analog input for U_NTC enabled.
  ADC10AE0 = (U_NTC);

  // Input channel set to 5.
  ADC10CTL1 = INCH_5;
}

// _____________________________________________________________________________________
void setSREG(char pos) {
  char cnt = 0;
  // Turn off all LEDs --> 0000
  P2OUT &= ~BIT5;
  P2OUT |=  BIT5;

  // Set shift register to 'right shift'-mode
  P2OUT |= BIT0;

  // Select next input to be HIGH
  P2OUT |= BIT6;

  // CLK-signal: pos=1 --> 1000, pos=2 --> 1100 ...
  while (cnt < pos) {
	clkSignal();
	cnt++;
  }
}

// _____________________________________________________________________________________
void clkSignal() {
  P2OUT |=  BIT4;
  P2OUT &= ~BIT4;
}



// _____________________________________________________________________________________
// +++++++++++++++
// ++ INTERRUPT ++
// +++++++++++++++

// Port 1 interrupt vector.
#pragma vector = PORT1_VECTOR;
__interrupt void Port_1(void) {
	button_pressed = 1;
	P1IFG &= ~PB5;  // Enable interrupt.
}

// Timer interrupt vector @200Hz (REL on).
// Request data from ADC at @2Hz speed.
#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer_A(void) {
  if (cnt >= 100) {
	ADC10CTL0 |= ENC + ADC10SC;
	while (ADC10CTL1 & ADC10BUSY) {}
	heat = ADC10MEM;
  }
  if (heat < RANGE3) {
    P3OUT ^= REL_DYN;
  }
}
