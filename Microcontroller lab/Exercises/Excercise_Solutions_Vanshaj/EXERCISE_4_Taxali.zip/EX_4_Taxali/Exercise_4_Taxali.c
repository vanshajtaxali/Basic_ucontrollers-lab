/******************************EXERCISE 4***************************/
/*VANSHAJ TAXALI
 * Matriculation Nr. 4558621
 *
 */

#include <msp430.h> 
#include <templateEMP.h>
int m1,m2; // global integers m1 & m2 for potentiometer and ldr programs respectively
int r,g,b; //integers for red green and blue
int i;
void initial() // function to initialize the port and pins
{
    P2SEL=0;
    P2SEL2=0;
    P3SEL=0;
    P3SEL2=0;
    P2DIR |= BIT0 + BIT1 + BIT4 + BIT5 + BIT6;
    P2OUT &= ~BIT4;
    P3DIR |= BIT0 + BIT1 + BIT2;
    P1DIR &= ~BIT7;
    P1DIR &= ~BIT4;
}

void clock(int x) //function to generate clock with x as an argument and it decides number of clocks
{
    while(x>0)
    {
        P2OUT |=BIT4;
        P2OUT &= ~BIT4;
        x--;
    }
}
void clear_reg() //fuction to clear shift register 2
{
    P2OUT &= ~BIT5;
    P2OUT |=BIT5;
}

void rshift2()  //function to set right shift direction of the data in register 2
{
    P2OUT |=BIT0;
    P2OUT &= ~BIT1;
}
void lshift2()      //function to set left shift direction of the data in register 2
{
    P2OUT |=BIT1;
        P2OUT &= ~BIT0;

}
void potentiom() // function to synchronize led with led D1-D4
{
      clear_reg();  //clearing the register
    if(m1<205)
    {
        P2OUT &= ~BIT6;
        P2OUT |= BIT0 + BIT1;
        clock(1);
    }
    else if(m1>205 && m1<=410)
    {
        P2OUT |= BIT6;
        rshift2();
        clock(1);
        lshift2();
        clock(3);
    }
    else if(m1>410 && m1<=615)
    {
        P2OUT |= BIT6;
              rshift2();
              clock(2);
              lshift2();
              clock(2);
    }
    else if(m1>615 && m1<=820)
       {
           P2OUT |= BIT6;
                 rshift2();
                 clock(3);
                 lshift2();
                 clock(1);
       }
    else if(m1>820 && m1<=1025)
           {
                    P2OUT |= BIT6;
                     rshift2();
                     clock(4);

           }


}
void read(int f) //reading the values of potentiometer on serial monitor
{
    serialPrintInt (m1);
    serialPrintln ("");
    __delay_cycles(100000);

}
void led(int d)     //fuction to control red, blue & green Led to measure intensities
{
    if(d==0)
    {
        P3OUT |= BIT0;
        P3OUT &= ~(BIT1 + BIT2);
    }
    else if(d==1)
    {
        P3OUT |= BIT1;
        P3OUT &= ~(BIT0 + BIT2);
    }
    else if(d==2)
       {
           P3OUT |= BIT2;
           P3OUT &= ~(BIT0 + BIT1);
       }

    else
    {
        P3OUT &= ~(BIT1 + BIT2 + BIT0);
    }
}

void main () {
initMSP ();
initial(); //initialize ports and pins
led(3);
// Turn ADC on; use 16 clocks as sample & hold time ( see p. 559 in the user guide )
ADC10CTL0 = ADC10ON + ADC10SHT_2 ;
// Enable P1 .4 as AD input
ADC10AE0 |= BIT4 ;
// Select channel 4 as input for the following conversion (s)
ADC10CTL1 = INCH_4 ;
while (1)
{

// Start conversion
ADC10CTL0 |= ENC + ADC10SC ;
// Wait until result is ready

while ( ADC10CTL1 & ADC10BUSY );
// If result is ready , copy it to m1
m2 = ADC10MEM ; //storing the value from ldr in m2

//activate to Print m2 to the serial console
//read(m2);
while (m2>210) //using the value of m2 to read potentiometer i.e if tube is placed on ldr ADC will switch to channel 4 again
{
    ADC10CTL0 = ADC10ON + ADC10SHT_2;
    // Enable P1 .7 as AD input connected to potentiometer
    ADC10AE0 |= BIT7 ;
    // Select channel 7 as input for the following conversion (s)
ADC10CTL1 = INCH_7 ;
ADC10CTL0 |= ENC + ADC10SC ;
while ( ADC10CTL1 & ADC10BUSY );
m1 = ADC10MEM ; //storing the value from potentiometer to m1
    potentiom();
    ADC10CTL0 = ADC10ON + ADC10SHT_2;
       ADC10AE0 |= BIT4 ;
   ADC10CTL1 = INCH_4 ;
    ADC10CTL0 |= ENC + ADC10SC ;
                       while ( ADC10CTL1 & ADC10BUSY );
                       m2= ADC10MEM ; //updating  m2 from the values from LDR

}
/**************************colour detection*******************************************/
while(m2<210)//the different colour components measurement in this code is based on the no of cycles of while loop
   //giving time to ldr to become stable and then picking the final input
   //another way of doing is to take average value but will increase computations
{
    __delay_cycles(250000);
    i=5000; //given 5000 cycles
    while(i>0)
    {
        led(0);

    ADC10CTL0 |= ENC + ADC10SC ;
    while ( ADC10CTL1 & ADC10BUSY );
    r= ADC10MEM ;
i--;
    }
led(3); //turning off led's to avoid error
i=2000; //2000 cycles for green component as my ldr was sensitive towards green led
 __delay_cycles(250000);
 while(i>0)
 {
        led(1);
        ADC10CTL0 |= ENC + ADC10SC ;
            while ( ADC10CTL1 & ADC10BUSY );
            g = ADC10MEM ;
            i--;
 }

            led(3);
            i=5000; // 6000 cycles to get blue component
            __delay_cycles(250000);
            while(i>0)
            {
                led(2);
            ADC10CTL0 |= ENC + ADC10SC ;
                while ( ADC10CTL1 & ADC10BUSY );
                b= ADC10MEM ;
            i--;
            }

                led(3);
/************************************comparing the colour components***************************/
                if(r>g & r>b)
                   {
                       serialPrintln ("RED");
                   }
                if(g>r & g>b & g<147 & g>130)  // some pre defined data values are added which were measured beforehand using ldr
                    // this is done to make the code more precise however error may still persist
                                   {
                                       serialPrintln ("GREEN");
                                   }
                if(b>g & b>r & b<132)
                                   {
                                       serialPrintln ("BLUE");
                                   }
              if(r>147 & b>130 & g>170)
                                                   {
                                                     serialPrintln ("WHITE");

                                                 }
               if(r<100 & b<100 & g<100)
             {
                     serialPrintln ("BLACK");
             }

//resetting the comparing variables to 0
                r=0;
                g=0;
                b=0;
// again measuring m2 to decide to remain or exit the while loop
                ADC10CTL0 |= ENC + ADC10SC ;
                   while ( ADC10CTL1 & ADC10BUSY );
                   m2= ADC10MEM ;

}


    }



}







