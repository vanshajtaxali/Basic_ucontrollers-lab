/********Exercise 6******/
/*Name:Vanshaj Taxali
 * Mtr.Nr=4558621
 */
/* Connections:
 * P1.0 - X5  |  P1.3 - X7  |  P3.6 - CON4.1(left)
 * CON4.3(right)  - DAC_IN(X2)  |  CON4.2(middle) - X1
 */
#include <templateEMP.h>
#include<msp430.h>

//defining pins
#define COMP_OUT BIT3
#define REL_STAT BIT0
#define BUZZER BIT6

//Global Variables

static int interruptSet;
long time;
int buttonPressedTwice;

//array for melodies

int melody[2][5] = {
        {100 ,200,1500,600,120},
        {2000 ,1000,500,300,145},
};

/*****************Functions*************************/

void initialize() {
    // INPUT:
    P1DIR &= ~COMP_OUT;

    // OUTPUT:
    P1DIR |= REL_STAT;
    P3DIR |= BUZZER;

}
//interrupt initialization
void initInterrupt() {
    // Enable interrupt on P1.3.
    P1IE |= COMP_OUT;
    // Interrupt edge set to H-L (Button released).
    P1IES |= COMP_OUT;
    // Interuppt flag: interrupt is pending
    P1IFG &= ~COMP_OUT;
}


void initPWM(){
    // TA0.2 option
    P3SEL |= BUZZER;
    P3SEL2 &= ~BUZZER;
    // CCR2 set / reset
    TA0CCTL2 = OUTMOD_3;
    // PWM Period : 1000 us
    TA0CCR0 = 1000;
    // SMCLK ; MC_1 -> up mode ;
    TA0CTL = TASSEL_2 + MC_1;
}

void play(int tone) {
    TA0CCR0 = tone;
    TA0CCR2 = tone/2;

    __delay_cycles(500000);
}

void stop() {
    TA0CCR2 = 1000;
}

void playMelodyOne() {
    int i;
    for (i =3; i >= 0; i--) {
        play(melody[0][3 - i]);
        stop();
    }
}

void playMelodyTwo() {
    int i;
    for (i = 3; i >= 0; i--) {
        play(melody[1][3 - i]);
        stop();
    }
}
// Port 1 interrupt vector
# pragma vector = PORT1_VECTOR;
__interrupt void Port_1(void) {
    interruptSet++;
    P1IFG &= ~COMP_OUT;
}

int main () {
    initMSP();

   initialize();
    initInterrupt();
    initPWM();

    while (1) {
        // Set relay in 'detecting a tone'-mode.
        P1OUT &= ~REL_STAT;
        // Check that interrupts aren't set yet.
        interruptSet = 0;
        // Enable interrupts.
        P1IFG &= ~COMP_OUT;

        while (interruptSet < 1);
        //after interrupt is triggered

        // Disable interrupts.
        P1IFG |= COMP_OUT;

        // Used for debouncing purposes.
        _delay_cycles(50000);


        time = 0;
        buttonPressedTwice = 0;
 //here while is used for calculating waiting time if there is second or third tap
        while (time < 30000) {
            time++;
            //detecting the tap  and as the interrupt is disabled it will give an input
            if ((P1IN & COMP_OUT)) {
                buttonPressedTwice = 1;
            }
        }

        // Set relay in 'play a tone'-mode.
        P1OUT |= REL_STAT;

        if (buttonPressedTwice > 0) {
            playMelodyTwo();
        }
        else {
            playMelodyOne();
        }
    }
}


